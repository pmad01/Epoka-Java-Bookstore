package application.bookstore;

public class Main_  {
    // Run Application

    public static void main(String[] args) {
        Main.main(args);
    }

}
