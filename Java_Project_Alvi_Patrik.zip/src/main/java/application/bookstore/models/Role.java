package application.bookstore.models;

import java.io.Serializable;

public enum Role implements Serializable {
    MANAGER,
    LIBRARIAN,
    ADMIN
}
