# Java Project

## Aim of project : 
Learn JavaFX, MVC structure, Abstract classes, Event handlers, event listeners, observables, etc ...
Build a Library Management Application.

### Description to be updated soon ...


# Worked by :
[Alvi Dervishaj](https://github.com/AlviDervishaj) \
[Patrik Madhi](https://github.com/pmad01)

> Copyright &copy;  2022 - current
